__declspec(naked) void __cdecl sub_00018E30(void) {
    __asm {
        _emit 0x8B
        _emit 0x41
        _emit 0x34
        _emit 0xC3
    }
}
