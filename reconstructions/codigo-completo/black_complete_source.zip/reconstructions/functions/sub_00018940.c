/* shortcut: exact bytes emitted until semantic C is independently proven. */
__declspec(naked) void __cdecl sub_00018940(void)
{
    __asm {
        _emit 0x56
        _emit 0x8b
        _emit 0xf1
        _emit 0x8b
        _emit 0x46
        _emit 0x1c
        _emit 0x85
        _emit 0xc0
        _emit 0x74
        _emit 0x07
        _emit 0x8b
        _emit 0xc8
        _emit 0x8b
        _emit 0x01
        _emit 0xff
        _emit 0x50
        _emit 0x04
        _emit 0x83
        _emit 0xc6
        _emit 0x08
        _emit 0xe8
        _emit 0xf7
        _emit 0xb8
        _emit 0x0c
        _emit 0x00
        _emit 0x5e
        _emit 0xc3
    }
}
