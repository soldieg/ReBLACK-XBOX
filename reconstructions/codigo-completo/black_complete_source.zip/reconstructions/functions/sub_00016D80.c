__declspec(naked) void __cdecl sub_00016D80(void) {
    __asm {
        _emit 0x8B
        _emit 0xC1
        _emit 0xC7
        _emit 0x00
        _emit 0xA0
        _emit 0xF5
        _emit 0x28
        _emit 0x00
        _emit 0xC2
        _emit 0x04
        _emit 0x00
    }
}
