/* shortcut: address-pinned byte emitter preserves exact candidate bytes; replace only after semantic C matches at the final link address. */
__declspec(naked) void __cdecl sub_00017B90(void)
{
    __asm {
        _emit 0x39
        _emit 0x81
        _emit 0x60
        _emit 0x01
        _emit 0x00
        _emit 0x00
        _emit 0x74
        _emit 0x20
        _emit 0x0F
        _emit 0x57
        _emit 0xC0
        _emit 0x8B
        _emit 0x15
        _emit 0xD4
        _emit 0x45
        _emit 0x2D
        _emit 0x00
        _emit 0x89
        _emit 0x81
        _emit 0x60
        _emit 0x01
        _emit 0x00
        _emit 0x00
        _emit 0x8B
        _emit 0x01
        _emit 0xF3
        _emit 0x0F
        _emit 0x11
        _emit 0x81
        _emit 0x58
        _emit 0x01
        _emit 0x00
        _emit 0x00
        _emit 0x8B
        _emit 0x52
        _emit 0x1C
        _emit 0x52
        _emit 0xFF
        _emit 0x50
        _emit 0x04
        _emit 0xC3
    }
}
